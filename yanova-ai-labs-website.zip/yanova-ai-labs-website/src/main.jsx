import React from 'react';
import { createRoot } from 'react-dom/client';
import { Cloud, Activity, Shield, Bot, BarChart3, Rocket } from 'lucide-react';
import './styles.css';

function App() {
  return (
    <main>
      <nav className="nav">
        <div className="brand"><span className="logo">Y</span> Yanova AI Labs</div>
        <div className="links">
          <a href="#products">Products</a>
          <a href="#mvp">MVP</a>
          <a href="#vision">Vision</a>
          <a href="#contact">Contact</a>
        </div>
      </nav>

      <section className="hero">
        <div className="badge">Observe. Analyze. Automate.</div>
        <h1>Intelligence for Every Business</h1>
        <p>
          Yanova AI Labs builds AI-powered automation, observability, analytics,
          and one-click infrastructure solutions for modern enterprises.
        </p>
        <div className="buttons">
          <a className="primary" href="#mvp">Explore Yanova OneClick</a>
          <a className="secondary" href="#products">View Products</a>
        </div>
      </section>

      <section id="mvp" className="panel">
        <div>
          <h2>First MVP: Yanova OneClick</h2>
          <p>
            Deploy production-ready Kubernetes clusters in minutes, not days.
            Start with AWS EKS automation using Terraform and intelligent dashboards.
          </p>
        </div>
        <div className="deploy-card">
          <h3>One-Click EKS Deployment</h3>
          <ul>
            <li>AWS VPC, Subnets, IAM</li>
            <li>EKS Cluster + Node Groups</li>
            <li>Monitoring, Logging, Ingress</li>
            <li>Cluster Health + Cost Dashboard</li>
          </ul>
          <button>Deploy Cluster</button>
        </div>
      </section>

      <section id="products" className="grid-section">
        <h2>Product Vision</h2>
        <div className="grid">
          <Card icon={<Rocket />} title="Yanova OneClick" text="One-click cloud and Kubernetes infrastructure automation." />
          <Card icon={<Bot />} title="Yanova AI Ops" text="AI assistant for cloud, Linux, DevOps, and operations teams." />
          <Card icon={<Activity />} title="Yanova Observability" text="Metrics, logs, traces, alerts, and operational intelligence." />
          <Card icon={<BarChart3 />} title="Yanova Insights" text="Real-time user, product, business, and executive dashboards." />
          <Card icon={<Shield />} title="Yanova Compliance" text="Security checks, governance, and automated compliance reports." />
          <Card icon={<Cloud />} title="Yanova MarketIQ" text="Future stock and market intelligence dashboards." />
        </div>
      </section>

      <section id="vision" className="vision">
        <h2>Why Yanova AI Labs?</h2>
        <p>
          We combine infrastructure automation, AI insights, real-time metrics,
          and one-click actions to help teams move faster with confidence.
        </p>
      </section>

      <footer id="contact">
        <strong>Yanova AI Labs</strong>
        <span>© Yanova Labs Pvt. Ltd. | yanovalabs.com</span>
      </footer>
    </main>
  );
}

function Card({ icon, title, text }) {
  return (
    <div className="card">
      <div className="icon">{icon}</div>
      <h3>{title}</h3>
      <p>{text}</p>
    </div>
  );
}

createRoot(document.getElementById('root')).render(<App />);
